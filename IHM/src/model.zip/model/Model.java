package model;

public class Model {
    // Ajoutez le DAO et les méthodes de traitement des données ici pour les
    // renvoyer au contrôleur
}
